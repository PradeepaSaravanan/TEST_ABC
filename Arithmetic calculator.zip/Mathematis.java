package AssistedProject;

public interface Mathematis {

	double addition(double num1, double num2);
	double subtraction(double num1, double num2);
	double multiplicaiton(double num1, double num2);
	double division(double num1, double num2);
}
